package patchmaster.uchoas.app.patchmaster;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.Buffer;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import patchmaster.uchoas.app.patchmaster.MainActivity;

import static patchmaster.uchoas.app.patchmaster.MainActivity.ac;
import static patchmaster.uchoas.app.patchmaster.MainActivity.fProp;
import static patchmaster.uchoas.app.patchmaster.MainActivity.msg;
import static patchmaster.uchoas.app.patchmaster.MainActivity.pd;

public class ZipManager {

    private static final int BUFFER = 80000;
    private static List<String> fileList;

    public void zipIt(String zipFile, String arquivos) {
        fileList = new ArrayList<>();
        generateFileList(new File(arquivos), arquivos);

        byte[] buffer = new byte[BUFFER];
        String source = new File(arquivos).getName();
        FileOutputStream fos = null;
        ZipOutputStream zos = null;
        try {
            fos = new FileOutputStream(zipFile);
            zos = new ZipOutputStream(fos);

            int prog = 0, atual = 0;

            FileInputStream in = null;

            for (String file: this.fileList) {

                ZipEntry ze = new ZipEntry(source + File.separator + file);

                ze.setMethod(ZipEntry.DEFLATED);
                String extension = "";
                int i = file.lastIndexOf('.');
                if (i > 0) {
                    extension = file.substring(i+1);
                    if(extension.equals("ogg")){
                        for(filesZipProp li : fProp){
                            if(li.getName().equals(ze.getName().substring(7))){
                                ze.setMethod(ZipEntry.STORED);
                                ze.setSize(li.getSize());
                                ze.setCompressedSize(li.getSizeComp());
                                ze.setCrc(li.getCrc());
                            }
                        }

                    }
                }

                zos.putNextEntry(ze);
                try {
                    in = new FileInputStream(arquivos + File.separator + file);

                    pd.setProgress(0);
                    atual++;
                    int len, fez = 0, ant = 0, tam = (int)ze.getSize();
                    msg = "COMPACTANDO...\n" + file + "\n" + atual + "/" + fileList.size();
                    ac.runOnUiThread(changeText);

                    while ((len = in.read(buffer)) > 0) {
                        zos.write(buffer, 0, len);

                        fez += len;
                        prog = (fez * 100) / tam;
                        if(prog > ant) {
                            pd.setProgress(prog);
                            ant = prog;
                        }

                    }
                } finally {
                    in.close();
                }
            }

            zos.closeEntry();

        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                zos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void generateFileList(File node, String arquivos) {
        // add file only
        if (node.isFile()) {
            fileList.add(generateZipEntry(node.toString(), arquivos));
        }

        if (node.isDirectory()) {
            String[] subNote = node.list();
            for (String filename: subNote) {
                generateFileList(new File(node, filename), arquivos);
            }
        }
    }

    private String generateZipEntry(String file, String arquivos) {
        return file.substring(arquivos.length() + 1, file.length());
    }





    // *********************************************************************************************





    public void extract(String fileZip, File target) throws IOException {
        ZipInputStream zip = null;
        try {
            ZipEntry entry;
            zip = new ZipInputStream(new FileInputStream(fileZip));

            int prog = 0, atual = 0;

            while ((entry = zip.getNextEntry()) != null) {
                File file = new File(target, entry.getName());

                /*if (!file.toPath().normalize().startsWith(target.toPath())) {
                    throw new IOException("Bad zip entry");
                }*/

                fProp.add(new filesZipProp(entry.getName().substring(7),/*entry.getMethod(),*/entry.getSize(),entry.getCompressedSize(),entry.getCrc()));

                if (entry.isDirectory()) {
                    file.mkdirs();
                    continue;
                }

                byte[] buffer = new byte[BUFFER];
                file.getParentFile().mkdirs();
                BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(file));

                pd.setProgress(0);
                atual++;
                int count, fez = 0, ant = 0, tam = (int)entry.getSize();
                msg = "EXTRAINDO...\n" + file.getName() + "\n" + atual + "/" + new ZipFile(fileZip).size();
                ac.runOnUiThread(changeText);

                while ((count = zip.read(buffer)) != -1) {
                    out.write(buffer, 0, count);

                    fez += count;
                    prog = (fez * 100) / tam;
                    if(prog > ant) {
                        pd.setProgress(prog);
                        ant = prog;
                    }

                }

                out.close();
            }
        } finally {
            zip.close();
        }
    }



















    private Runnable changeText = new Runnable() {
        @Override
        public void run() {
            pd.setMessage(msg);
        }
    };


}
