package patchmaster.uchoas.app.patchmaster;

public class filesZipProp {

    private String name;
    //private int method;
    private long size;
    private long sizeComp;
    private long crc;

    public filesZipProp(String name,/* int method,*/ long size, long sizeComp, long crc) {
        this.name = name;
        //this.method = method;
        this.size = size;
        this.sizeComp = sizeComp;
        this.crc = crc;
    }

    public String getName() {
        return name;
    }

    /*public int getMethod() {
        return method;
    }*/

    public long getSize() {
        return size;
    }

    public long getSizeComp() {
        return sizeComp;
    }

    public long getCrc() {
        return crc;
    }

}
