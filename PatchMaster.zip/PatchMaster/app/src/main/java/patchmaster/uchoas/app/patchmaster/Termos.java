package patchmaster.uchoas.app.patchmaster;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

public class Termos extends AppCompatActivity {

    CheckBox cb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_termos);

        cb = findViewById(R.id.check);
    }

    public void continuar(View view) {
        if(cb.isChecked()){
            SharedPreferences.Editor editor = getSharedPreferences("variaveis", MODE_PRIVATE).edit();
            editor.putBoolean("primeiroInicio",false);
            editor.commit();
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        // não chame o super desse método
    }

}
