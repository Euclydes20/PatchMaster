package patchmaster.uchoas.app.patchmaster;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class suporte extends AppCompatActivity {

    EditText et_nome;
    EditText et_msg;
    boolean te = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suporte);
        et_nome = findViewById(R.id.et_nome);
        et_msg = findViewById(R.id.et_msg);
    }

    public void sendEmail(View view) {

        String[] email = {"app.patch.master@gmail.com"};
        String sbj = et_nome.getText().toString() + ", preciso de suporte no Patch Master";
        String msg = et_msg.getText().toString();
        Intent in = new Intent(Intent.ACTION_SEND);
        in.putExtra(Intent.EXTRA_EMAIL, email);
        in.putExtra(Intent.EXTRA_SUBJECT, sbj);
        in.putExtra(Intent.EXTRA_TEXT, msg);
        in.setType("message/rfc822");
        try {
            startActivity(Intent.createChooser(in,"Escolha um App de EMAIL para Enviar"));
            te = true;
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "Ops, voce nao tem algum app de email instalado em seu aparelho", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        if(te) {
            te = false;
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false);
            builder.setTitle("Atenção");
            builder.setMessage("O email de suporte foi enviado e você será respondido em breve, obrigado por utilizar o Patch Master.");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    finish();
                }
            });
            builder.create().show();
        }
    }

}
