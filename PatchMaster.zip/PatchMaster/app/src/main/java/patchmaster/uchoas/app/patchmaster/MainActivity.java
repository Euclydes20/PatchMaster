package patchmaster.uchoas.app.patchmaster;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends AppCompatActivity {

    String inputPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/PatchMaster/Temp";
    String inputPath2 = Environment.getExternalStorageDirectory().getAbsolutePath() + "/PatchMaster/Temp2";
    String obbDir = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/obb/";
    String inputFile; // = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/obb/com.bscotch.crashlands/main.1004033.com.bscotch.crashlands.obb";
    static ProgressDialog pd;
    static String msg = "", txt = "";
    String nome = "", sub = "", tipo = "";
    List<String> FILE_URL_ORIGIN = new ArrayList<>();
    List<String> FILE_NAME_ORIGIN = new ArrayList<>();
    static Activity ac;
    static Thread th = new Thread();
    boolean sucesso = true;
    static boolean pu = false;
    SharedPreferences sp;
    public static List<filesZipProp> fProp = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checarpermissao();
        ac = this;

        sp = getSharedPreferences("variaveis", Context.MODE_PRIVATE);
        pu = sp.getBoolean("primeiroInicio",true);

        verificarAceitacaoTermo();
        //startActivity(new Intent(MainActivity.this, teste.class));
    }


    public void checarpermissao() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET}, 1);
        }

    }


    public void verificarAceitacaoTermo(){
        if(pu == true){
            Intent intent = new Intent(MainActivity.this, Termos.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }

    }


    /*@Override
    public void onResume() {
        super.onResume();
        if(pu == true){
            startActivity(new Intent(MainActivity.this, Termos.class));
        }
    }*/


    public void crashlands(View v) {
        inputFile = obbDir + "com.bscotch.crashlands/main.1004033.com.bscotch.crashlands.obb";
        FILE_URL_ORIGIN = new ArrayList<>();
        FILE_URL_ORIGIN.add("https://drive.google.com/uc?export=download&id=1C54ibMVLbOOMjFn5cmbkk9n77eW4Rwg2");
        FILE_NAME_ORIGIN = new ArrayList<>();
        FILE_NAME_ORIGIN.add("english.json");
        nome = "CRASHLANDS";
        sub = File.separator + "assets";
        tipo = "PATCHEAMENTO";
        aplicarPatch();
    }
    public void crashlands2(View v) {
        inputFile = obbDir + "com.bscotch.crashlands/main.1004033.com.bscotch.crashlands.obb";
        FILE_URL_ORIGIN = new ArrayList<>();
        FILE_URL_ORIGIN.add("https://drive.google.com/uc?export=download&id=1C54ibMVLbOOMjFn5cmbkk9n77eW4Rwg2");
        FILE_NAME_ORIGIN = new ArrayList<>();
        FILE_NAME_ORIGIN.add("english.json");
        nome = "CRASHLANDS";
        sub = File.separator + "assets";
        tipo = "RESTAURACAO";
        aplicarPatch();
    }


    public void sttt(View v) {
        inputFile = obbDir + "com.gonzossm.sttt/main.117275.com.gonzossm.sttt.obb";
        FILE_URL_ORIGIN = new ArrayList<>();
        //FILE_URL_ORIGIN.add("https://srv-file4.gofile.io/download/zIymOC/info_load_file.json");
        FILE_URL_ORIGIN.add("https://drive.google.com/uc?export=download&id=1Jnvci2IbCsI14bUSINKgJDBdLao6kJIl");
        FILE_NAME_ORIGIN = new ArrayList<>();
        FILE_NAME_ORIGIN.add("info_load_file.json");
        nome = "SUPER TOSS THE TURTLE";
        sub = File.separator + "assets";
        tipo = "PATCHEAMENTO";
        aplicarPatch();
    }
    public void sttt2(View v) {
        inputFile = obbDir + "com.gonzossm.sttt/main.117275.com.gonzossm.sttt.obb";
        FILE_URL_ORIGIN = new ArrayList<>();
        //FILE_URL_ORIGIN.add("https://srv-file4.gofile.io/download/NlTRHi/info_load_file.json");
        FILE_URL_ORIGIN.add("https://drive.google.com/uc?export=download&id=1EnDR-4cZQ8npHI4ntvgotoBPfcRjmHtQ");
        FILE_NAME_ORIGIN = new ArrayList<>();
        FILE_NAME_ORIGIN.add("info_load_file.json");
        nome = "SUPER TOSS THE TURTLE";
        sub = File.separator + "assets";
        tipo = "RESTAURACAO";
        aplicarPatch();
    }


    public void aplicarPatch(){

        sucesso = true;

        if (!new File(inputPath).exists()) {
            new File(inputPath).mkdirs();
        }
        if (!new File(inputPath2).exists()) {
            new File(inputPath2).mkdirs();
        }

        if (new File(inputFile).exists()) {

            /*pd = new ProgressDialog(MainActivity.this);
            pd.setMessage("INICIANDO...");
            pd.setTitle("Aguarde por favor...");
            pd.setCancelable(false);
            pd.show();*/

            pd = new ProgressDialog(this);
            pd.setTitle(tipo + " DE " + nome);
            pd.setMessage("INICIANDO...");
            pd.setMax(100);
            pd.setCancelable(false);
            pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            pd.show();

            new Thread(new Runnable() {
                @Override
                public void run() {

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    pd.setProgress(0);
                    msg = "PREPARANDO PARA BAIXAR ARQUIVOS NECESSARIOS PARA O PATCHEAMENTO";
                    runOnUiThread(changeText);
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    baixar();

                    if(sucesso == true) {

                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        pd.setProgress(0);
                        msg = "RESGATANDO ARQUIVOS DO ZIP";
                        runOnUiThread(changeText);
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        ZipManager zm = new ZipManager();
                        try {
                            zm.extract(inputFile, new File(inputPath2));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        pd.setProgress(0);
                        msg = "PATCHEANDO ARQUIVOS";
                        runOnUiThread(changeText);
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        try {
                            copiarTeste(new File(""), new File(""));
                        } catch (IOException e) {
                        }

                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        pd.setProgress(0);
                        msg = "COMPACTANDO ARQUIVOS PARA UM NOVO ZIP";
                        runOnUiThread(changeText);
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        ZipManager zipManager = new ZipManager();
                        zipManager.zipIt(inputFile, inputPath2 + sub);

                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        pd.setProgress(0);
                        msg = "APAGANDO ARQUIVOS TEMPORARIOS";
                        runOnUiThread(changeText);
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        File tempFiles = new File(inputPath);
                        remover(tempFiles, 0);
                        File tempFiles2 = new File(inputPath2);
                        remover(tempFiles2, 0);
                        pd.setProgress(100);

                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        msg = "FINALIZADO";
                        runOnUiThread(changeText);

                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                    }

                    pd.dismiss();
                    sucesso = true;

                }
            }).start();

        } else {
            Toast.makeText(this, "NÃO FOI DETECTADO O ARQUIVO A SER PATCHEADO!", Toast.LENGTH_SHORT).show();
        }

    }


    private Runnable changeText = new Runnable() {
        @Override
        public void run() {
            pd.setMessage(msg);
        }
    };


    private Runnable mostrarToast = new Runnable() {
        @Override
        public void run() {
            Toast.makeText(ac, txt, Toast.LENGTH_LONG).show();
        }
    };


    private Runnable mostrarAlert = new Runnable() {
        @Override
        public void run() {
            AlertDialog.Builder builder = new AlertDialog.Builder(ac);
            builder.setCancelable(false);
            builder.setTitle("Não foi possível baixar o arquivo!");
            builder.setMessage("Por favor verifique sua conexao e tente novamente.");
            builder.setPositiveButton("OK", null);
            builder.create().show();
        }
    };


    private void baixar(){

        try {
            int BUFFER = 8192, prog = 0, atual = 0;
            for (String FILE_URL : FILE_URL_ORIGIN) {
                pd.setProgress(0);
                atual++;
                msg  = "CONECTANDO A \n" + FILE_URL + " \n... AGUARDE...\n" + atual + "/" + FILE_URL_ORIGIN.size();
                runOnUiThread(changeText);
                HttpURLConnection conn = null;
                URL url = new URL(FILE_URL);
                conn = (HttpURLConnection) url.openConnection();
                if((conn == null) || (conn.getHeaderField("Content-Disposition") == null) || (conn.getResponseCode() != 200)){
                    sucesso = false;
                    pd.dismiss();
                    runOnUiThread(mostrarAlert);
                    break;
                }
                /*while(conn.getHeaderField("Content-Disposition").equals("")){
                    conn = url.openConnection();
                }*/
                int tam = conn.getContentLength();
                String FILE_NAME = conn.getHeaderField("Content-Disposition").split("=")[1].replaceAll("\"", "").split(";")[0];
                String FILE_DIR = inputPath + File.separator + FILE_NAME;
                try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
                    FileOutputStream fileOutputStream = new FileOutputStream(FILE_DIR)) {
                    byte dataBuffer[] = new byte[BUFFER];
                    int bytesRead, fez = 0, ant = 0;
                    msg = "BAIXANDO...\n" + FILE_NAME + "\n" + atual + "/" + FILE_URL_ORIGIN.size();
                    runOnUiThread(changeText);
                    while ((bytesRead = in.read(dataBuffer, 0, BUFFER)) != -1) {
                        fileOutputStream.write(dataBuffer, 0, bytesRead);
                        fez += bytesRead;
                        prog = (fez * 100) / tam;
                        if(prog > ant) {
                            pd.setProgress(prog);
                            ant = prog;
                        }
                    }
                } catch (IOException e) {
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
                }
                ((HttpURLConnection) conn).disconnect();
            }
            msg = "DOWNLOAD FINALIZADO !!!";
            runOnUiThread(changeText);
        } catch (MalformedURLException e) {
            //runOnUiThread(erro(e.toString()));
            //Toast.makeText(ac, e.toString(), Toast.LENGTH_SHORT).show();
            txt = e.toString();
            runOnUiThread(mostrarToast);
        } catch (IOException e) {
            //runOnUiThread(erro(e.toString()));
            //Toast.makeText(ac, e.toString(), Toast.LENGTH_SHORT).show();
            txt = e.toString();
            runOnUiThread(mostrarToast);
        }

    }


    public static boolean isConnected(URLConnection con) {
        try {
            con.setDoOutput(con.getDoOutput()); // throws IllegalStateException if connected
            return false;
        } catch (IllegalStateException e) {
            return true;
        }
    }


    private int contarzipfiles() {
        int count = 0;
        try {
            FileInputStream fis_v = null;
            try {
                fis_v = new FileInputStream(inputFile);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            ZipInputStream zis_v = new ZipInputStream(fis_v);
            ZipEntry ze_v = null;
            while (true) {
                try {
                    if (!((ze_v = zis_v.getNextEntry()) != null)) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (!ze_v.isDirectory()) {
                    count++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }


    private void copiarTeste(File fonte, File destino) throws IOException {

        int atual = 0;
        for (String FILE_NAME : FILE_NAME_ORIGIN) {
            pd.setProgress(0);
            atual++;
            fonte = new File(inputPath + File.separator + FILE_NAME);
            destino = new File(inputPath2 + sub + File.separator + FILE_NAME);
            if (destino.exists()) {
                destino.delete();
            }
            InputStream in = new FileInputStream(fonte);
            OutputStream out = new FileOutputStream(destino);
            byte[] buf = new byte[1024];
            int len, fez = 0, ant = 0, prog = 0, tam = 0;
            msg = "PATCHEANDO...\n" + FILE_NAME + "\n" + atual + "/" + FILE_NAME_ORIGIN.size();
            runOnUiThread(changeText);
            tam = (int)fonte.length();
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
                fez += len;
                prog = (fez * 100) / tam;
                if(prog > ant) {
                    pd.setProgress(prog);
                    ant = prog;
                }
            }
            in.close();
            out.close();
        }
        msg = "PATCHEAMENTO FINALIZADO !!!";
        runOnUiThread(changeText);

    }


    public void remover(File f, int n) {
        if (f.isDirectory()) {
            File[] files = f.listFiles();
            for (int i = 0; i < files.length; i++) {
                remover(files[i], 1);
            }
        }
        if (n == 1) {
            msg = "APAGANDO: " + f.toString();
            runOnUiThread(changeText);
            f.delete();
        }
    }



    /*private void copiar(AssetManager assetManager, String[] s) {
        for(String filename : s) {
            InputStream in = null;
            OutputStream out = null;
            try {
                in = assetManager.open(filename);

                File outFile = new File(inputPath, "/"+filename);

                out = new FileOutputStream(outFile);

                byte[] buffer = new byte[1024];
                int read;
                while((read = in.read(buffer)) != -1){
                    out.write(buffer, 0, read);
                }

                in.close();
                in = null;
                out.flush();
                out.close();
                out = null;
            } catch(IOException e) {
                //Log.e("tag", "Failed to copy asset file: " + filename, e);
                Toast.makeText(this, "Failed to copy asset file !!!", Toast.LENGTH_SHORT).show();
            }
        }

    }*/


    private void copiarAss(AssetManager assetManager, String[] s, String[] arq) {

        boolean valido = false;
        if (s != null) {
            for (String filename : s) {
                for (String f : arq) {
                    if (f.equals(filename)) {
                        valido = true;
                        break;
                    }
                }
                if (valido == true) {
                    valido = false;
                    InputStream in = null;
                    OutputStream out = null;
                    try {
                        in = assetManager.open(filename);
                        File outFile = new File(inputPath + File.separator + filename);
                        if (outFile.exists()) {// File does not exist...
                            //out = new FileOutputStream(outFile);
                            //copyFile(in, out);
                            outFile.delete();
                        }
                        out = new FileOutputStream(outFile);
                        copyFile(in, out);
                    } catch (IOException e) {
                        //Log.e("tag", "Failed to copy asset file: " + filename, e);
                        Toast.makeText(this, "ERRO CATCH !!!" + e.toString(), Toast.LENGTH_SHORT).show();
                    } finally {
                        if (in != null) {
                            try {
                                in.close();
                            } catch (IOException e) {
                                // NOOP
                            }
                        }
                        if (out != null) {
                            try {
                                out.close();
                            } catch (IOException e) {
                                // NOOP
                            }
                        }
                    }
                }
            }
        } else {
            Toast.makeText(this, "ARQUIVOS NULOS !!!", Toast.LENGTH_SHORT).show();
        }

    }

    private void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
    }


    private void deletar() {

        File f = new File(inputPath);
        if (f.isDirectory()) {
            File[] del = f.listFiles();
            for (File toDelete : del) {
                toDelete.delete();
            }
        }

    }

    public void goSuporte(View view) {
        startActivity(new Intent(MainActivity.this, suporte.class));
    }

}
